<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="/css/usin.css">
  <title>Document</title>
</head>
<body>
<div class="usin">
  <div class="one" style="background-color: green; "></div>
  <div class="two" style="background-color: red; "></div>
  <div class="three" style="background-color: blue; "></div>
  <div class="four" style="background-color: magenta; "></div>
  <div class="five" style="background-color: yellow; "></div>
<div class='one_one ".$data[1]['color']."' data-toggle='tooltip' title='Дневная доменанта'>".$data[1]['0']."<br>Дневная доменанта</div>
<div class='one_two ".$data[1]['color']."' data-toggle='tooltip' title='".$data[1]['1']."'>".$data[1]['0']."<br>".$data[1]['1']."</div>
<div class='one_three ".$data[2]['color']."' data-toggle='tooltip' title='".$data[2]['1']."'>".$data[2]['0']."<br>".$data[2]['1']."</div>
<div class='two_one ".$data[3]['color']."' data-toggle='tooltip' title='".$data[3]['1']."'>".$data[3]['0']."<br>".$data[3]['1']."</div>
<div class='two_two ".$data[4]['color']."' data-toggle='tooltip' title='".$data[4]['1']."'>".$data[4]['0']."<br>".$data[4]['1']."</div>
<div class='three_one ".$data[5]['color']."' data-toggle='tooltip' title='".$data[5]['1']."'>".$data[5]['0']."<br>".$data[5]['1']."</div>
<div class='three_two ".$data[6]['color']."' data-toggle='tooltip' title='".$data[6]['1']."'>".$data[6]['0']."<br>".$data[6]['1']."</div>
<div class='four_one ".$data[7]['color']."' data-toggle='tooltip' title='".$data[7]['1']."'>".$data[7]['0']."<br>".$data[7]['1']."</div>
<div class='four_two ".$data[8]['color']."' data-toggle='tooltip' title='".$data[8]['1']."'>".$data[8]['0']."<br>".$data[8]['1']."</div>
<div class='five_one ".$data[9]['color']."' data-toggle='tooltip' title='".$data[9]['1']."'>".$data[9]['0']."<br>".$data[9]['1']."</div>
<div class='five_two ".$data[10]['color']."' data-toggle='tooltip' title='".$data[10]['1']."'>".$data[10]['0']."<br>".$data[10]['1']."</div>

</div>
</body>
</html>
